-- ============================================================
--  ERP RETAIL — Esquema PostgreSQL
--  Migración 001: Tablas base completas
-- ============================================================

-- Extensión para UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
--  USUARIOS Y CONTROL DE ACCESO
-- ============================================================

CREATE TYPE rol_usuario AS ENUM ('admin', 'vendedor', 'deposito', 'compras');

CREATE TABLE usuarios (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nombre        VARCHAR(100)  NOT NULL,
  apellido      VARCHAR(100)  NOT NULL,
  email         VARCHAR(255)  NOT NULL UNIQUE,
  password_hash VARCHAR(255)  NOT NULL,
  rol           rol_usuario   NOT NULL DEFAULT 'vendedor',
  activo        BOOLEAN       NOT NULL DEFAULT TRUE,
  ultimo_acceso TIMESTAMPTZ,
  creado_en     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  actualizado_en TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE sesiones (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  usuario_id  UUID         NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  token_hash  VARCHAR(255) NOT NULL UNIQUE,
  ip          VARCHAR(45),
  user_agent  TEXT,
  expira_en   TIMESTAMPTZ  NOT NULL,
  creado_en   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE auditoria (
  id          BIGSERIAL PRIMARY KEY,
  usuario_id  UUID        REFERENCES usuarios(id) ON DELETE SET NULL,
  accion      VARCHAR(100) NOT NULL,
  tabla       VARCHAR(100),
  registro_id TEXT,
  detalle     JSONB,
  ip          VARCHAR(45),
  creado_en   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
--  CATÁLOGO DE PRODUCTOS
-- ============================================================

CREATE TABLE categorias (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nombre          VARCHAR(100) NOT NULL,
  descripcion     TEXT,
  tiene_vencimiento BOOLEAN    NOT NULL DEFAULT FALSE,
  categoria_padre UUID         REFERENCES categorias(id) ON DELETE SET NULL,
  activa          BOOLEAN      NOT NULL DEFAULT TRUE,
  creado_en       TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE marcas (
  id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nombre    VARCHAR(100) NOT NULL UNIQUE,
  activa    BOOLEAN      NOT NULL DEFAULT TRUE,
  creado_en TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE unidades_medida (
  id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nombre    VARCHAR(50)  NOT NULL,
  simbolo   VARCHAR(10)  NOT NULL,
  creado_en TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Datos iniciales
INSERT INTO unidades_medida (nombre, simbolo) VALUES
  ('Unidad',    'un.'),
  ('Kilogramo', 'kg'),
  ('Litro',     'lt'),
  ('Metro',     'mt'),
  ('Caja',      'cj'),
  ('Pack',      'pk');

CREATE TABLE productos (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sku                 VARCHAR(50)    NOT NULL UNIQUE,
  codigo_barras       VARCHAR(50),
  nombre              VARCHAR(200)   NOT NULL,
  descripcion         TEXT,
  categoria_id        UUID           REFERENCES categorias(id) ON DELETE SET NULL,
  marca_id            UUID           REFERENCES marcas(id) ON DELETE SET NULL,
  unidad_medida_id    UUID           REFERENCES unidades_medida(id),
  -- Precios
  precio_costo        NUMERIC(12,2)  NOT NULL DEFAULT 0,
  precio_venta        NUMERIC(12,2)  NOT NULL DEFAULT 0,
  precio_mayorista    NUMERIC(12,2),
  moneda              CHAR(3)        NOT NULL DEFAULT 'UYU',
  -- Stock
  stock_minimo        INTEGER        NOT NULL DEFAULT 0,
  stock_maximo        INTEGER,
  ubicacion_deposito  VARCHAR(100),
  -- Atributos físicos (retail ropa/calzado)
  tiene_variantes     BOOLEAN        NOT NULL DEFAULT FALSE,
  -- Logística
  pais_origen         VARCHAR(100),
  unidad_compra       INTEGER        NOT NULL DEFAULT 1,  -- ej: caja x 12
  dias_entrega_prov   INTEGER,
  -- Control
  activo              BOOLEAN        NOT NULL DEFAULT TRUE,
  creado_por          UUID           REFERENCES usuarios(id) ON DELETE SET NULL,
  creado_en           TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  actualizado_en      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

-- Variantes de producto (talla, color, etc.)
CREATE TABLE producto_variantes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  producto_id UUID         NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
  sku_variante VARCHAR(50) NOT NULL UNIQUE,
  talla       VARCHAR(20),
  color       VARCHAR(50),
  descripcion VARCHAR(200),
  activa      BOOLEAN      NOT NULL DEFAULT TRUE,
  creado_en   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ============================================================
--  INVENTARIO Y LOTES
-- ============================================================

CREATE TABLE lotes (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  producto_id         UUID           NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
  variante_id         UUID           REFERENCES producto_variantes(id) ON DELETE CASCADE,
  numero_lote         VARCHAR(100)   NOT NULL,
  numero_serie        VARCHAR(100),
  fecha_fabricacion   DATE,
  fecha_vencimiento   DATE,
  fecha_recibido      DATE           NOT NULL DEFAULT CURRENT_DATE,
  stock_inicial       INTEGER        NOT NULL DEFAULT 0,
  stock_actual        INTEGER        NOT NULL DEFAULT 0,
  stock_reservado     INTEGER        NOT NULL DEFAULT 0,
  -- Trazabilidad
  proveedor_id        UUID,          -- FK a proveedores (se agrega al crear tabla)
  orden_compra_id     UUID,          -- FK a ordenes_compra (se agrega al crear tabla)
  -- Control
  activo              BOOLEAN        NOT NULL DEFAULT TRUE,
  creado_por          UUID           REFERENCES usuarios(id) ON DELETE SET NULL,
  creado_en           TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  actualizado_en      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  CONSTRAINT stock_no_negativo CHECK (stock_actual >= 0),
  CONSTRAINT stock_reservado_valido CHECK (stock_reservado >= 0)
);

CREATE INDEX idx_lotes_producto ON lotes(producto_id);
CREATE INDEX idx_lotes_vencimiento ON lotes(fecha_vencimiento) WHERE fecha_vencimiento IS NOT NULL;
CREATE INDEX idx_lotes_stock ON lotes(stock_actual) WHERE activo = TRUE;

-- Vista: stock total por producto (suma de todos los lotes activos)
CREATE VIEW v_stock_productos AS
SELECT
  p.id                            AS producto_id,
  p.sku,
  p.nombre,
  p.precio_venta,
  p.stock_minimo,
  COALESCE(SUM(l.stock_actual), 0)    AS stock_total,
  COALESCE(SUM(l.stock_reservado), 0) AS stock_reservado_total,
  COALESCE(SUM(l.stock_actual), 0) - COALESCE(SUM(l.stock_reservado), 0) AS stock_disponible,
  MIN(l.fecha_vencimiento)            AS proximo_vencimiento,
  COUNT(l.id)                         AS cantidad_lotes
FROM productos p
LEFT JOIN lotes l ON l.producto_id = p.id AND l.activo = TRUE
WHERE p.activo = TRUE
GROUP BY p.id, p.sku, p.nombre, p.precio_venta, p.stock_minimo;

-- Movimientos de inventario (trazabilidad completa)
CREATE TYPE tipo_movimiento AS ENUM (
  'entrada_compra', 'salida_venta', 'ajuste_positivo',
  'ajuste_negativo', 'merma', 'rotura', 'devolucion_cliente',
  'devolucion_proveedor', 'transferencia'
);

CREATE TABLE movimientos_inventario (
  id              BIGSERIAL PRIMARY KEY,
  lote_id         UUID              NOT NULL REFERENCES lotes(id),
  tipo            tipo_movimiento   NOT NULL,
  cantidad        INTEGER           NOT NULL,
  stock_anterior  INTEGER           NOT NULL,
  stock_nuevo     INTEGER           NOT NULL,
  referencia_tipo VARCHAR(50),   -- 'venta', 'orden_compra', 'ajuste'
  referencia_id   UUID,
  motivo          TEXT,
  usuario_id      UUID              REFERENCES usuarios(id) ON DELETE SET NULL,
  creado_en       TIMESTAMPTZ       NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_mov_lote ON movimientos_inventario(lote_id);
CREATE INDEX idx_mov_fecha ON movimientos_inventario(creado_en);

-- ============================================================
--  PROVEEDORES
-- ============================================================

CREATE TYPE estado_proveedor AS ENUM ('activo', 'inactivo', 'evaluacion', 'suspendido');

CREATE TABLE proveedores (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  razon_social    VARCHAR(200)    NOT NULL,
  nombre_fantasia VARCHAR(200),
  rut             VARCHAR(20)     UNIQUE,
  email           VARCHAR(255),
  telefono        VARCHAR(50),
  direccion       TEXT,
  ciudad          VARCHAR(100),
  pais            VARCHAR(100)    DEFAULT 'Uruguay',
  contacto_nombre VARCHAR(200),
  contacto_email  VARCHAR(255),
  contacto_tel    VARCHAR(50),
  -- Condiciones comerciales
  dias_pago       INTEGER         NOT NULL DEFAULT 30,
  descuento_pct   NUMERIC(5,2)    DEFAULT 0,
  moneda          CHAR(3)         NOT NULL DEFAULT 'UYU',
  -- Evaluación
  calificacion    NUMERIC(3,1)    DEFAULT 5.0,
  estado          estado_proveedor NOT NULL DEFAULT 'activo',
  notas           TEXT,
  creado_por      UUID            REFERENCES usuarios(id) ON DELETE SET NULL,
  creado_en       TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  actualizado_en  TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- Relación productos ↔ proveedores
CREATE TABLE proveedor_productos (
  proveedor_id    UUID           NOT NULL REFERENCES proveedores(id) ON DELETE CASCADE,
  producto_id     UUID           NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
  precio_costo    NUMERIC(12,2),
  codigo_proveedor VARCHAR(50),
  dias_entrega    INTEGER,
  activo          BOOLEAN        NOT NULL DEFAULT TRUE,
  PRIMARY KEY (proveedor_id, producto_id)
);

-- FKs diferidas (evita dependencias circulares)
ALTER TABLE lotes ADD CONSTRAINT fk_lote_proveedor
  FOREIGN KEY (proveedor_id) REFERENCES proveedores(id) ON DELETE SET NULL;

-- ============================================================
--  COMPRAS (ÓRDENES DE COMPRA)
-- ============================================================

CREATE TYPE estado_orden_compra AS ENUM (
  'borrador', 'enviada', 'confirmada', 'en_transito',
  'recibida_parcial', 'recibida', 'cancelada'
);

CREATE TABLE ordenes_compra (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  numero          VARCHAR(20)         NOT NULL UNIQUE,
  proveedor_id    UUID                NOT NULL REFERENCES proveedores(id),
  estado          estado_orden_compra NOT NULL DEFAULT 'borrador',
  fecha_emision   DATE                NOT NULL DEFAULT CURRENT_DATE,
  fecha_esperada  DATE,
  fecha_recepcion DATE,
  -- Totales
  subtotal        NUMERIC(12,2)       NOT NULL DEFAULT 0,
  descuento_pct   NUMERIC(5,2)        DEFAULT 0,
  impuesto_pct    NUMERIC(5,2)        DEFAULT 22,  -- IVA Uruguay
  total           NUMERIC(12,2)       NOT NULL DEFAULT 0,
  moneda          CHAR(3)             NOT NULL DEFAULT 'UYU',
  -- Condiciones
  dias_pago       INTEGER,
  notas           TEXT,
  -- Control
  creado_por      UUID                REFERENCES usuarios(id) ON DELETE SET NULL,
  aprobado_por    UUID                REFERENCES usuarios(id) ON DELETE SET NULL,
  creado_en       TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
  actualizado_en  TIMESTAMPTZ         NOT NULL DEFAULT NOW()
);

CREATE SEQUENCE seq_oc START 1;

CREATE TABLE ordenes_compra_items (
  id              UUID           PRIMARY KEY DEFAULT uuid_generate_v4(),
  orden_compra_id UUID           NOT NULL REFERENCES ordenes_compra(id) ON DELETE CASCADE,
  producto_id     UUID           NOT NULL REFERENCES productos(id),
  variante_id     UUID           REFERENCES producto_variantes(id),
  cantidad_pedida INTEGER        NOT NULL,
  cantidad_recibida INTEGER      NOT NULL DEFAULT 0,
  precio_unitario NUMERIC(12,2)  NOT NULL,
  subtotal        NUMERIC(12,2)  NOT NULL,
  -- Datos de lote a crear al recibir
  numero_lote     VARCHAR(100),
  fecha_vencimiento DATE,
  notas           TEXT
);

-- FK de lotes a orden de compra
ALTER TABLE lotes ADD CONSTRAINT fk_lote_orden_compra
  FOREIGN KEY (orden_compra_id) REFERENCES ordenes_compra(id) ON DELETE SET NULL;

-- ============================================================
--  CLIENTES
-- ============================================================

CREATE TABLE clientes (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nombre          VARCHAR(200)  NOT NULL,
  documento       VARCHAR(20),
  tipo_doc        VARCHAR(10)   DEFAULT 'CI',
  email           VARCHAR(255),
  telefono        VARCHAR(50),
  direccion       TEXT,
  es_mayorista    BOOLEAN       NOT NULL DEFAULT FALSE,
  activo          BOOLEAN       NOT NULL DEFAULT TRUE,
  creado_en       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  actualizado_en  TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ============================================================
--  VENTAS
-- ============================================================

CREATE TYPE estado_venta AS ENUM (
  'borrador', 'confirmada', 'pagada', 'cancelada', 'devuelta'
);

CREATE TYPE metodo_pago AS ENUM (
  'efectivo', 'tarjeta_debito', 'tarjeta_credito',
  'transferencia', 'mercadopago', 'credito_cuenta'
);

CREATE TABLE ventas (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  numero          VARCHAR(20)     NOT NULL UNIQUE,
  cliente_id      UUID            REFERENCES clientes(id) ON DELETE SET NULL,
  estado          estado_venta    NOT NULL DEFAULT 'borrador',
  fecha           DATE            NOT NULL DEFAULT CURRENT_DATE,
  -- Totales
  subtotal        NUMERIC(12,2)   NOT NULL DEFAULT 0,
  descuento_pct   NUMERIC(5,2)    DEFAULT 0,
  descuento_monto NUMERIC(12,2)   DEFAULT 0,
  impuesto_pct    NUMERIC(5,2)    DEFAULT 22,
  total           NUMERIC(12,2)   NOT NULL DEFAULT 0,
  moneda          CHAR(3)         NOT NULL DEFAULT 'UYU',
  -- Pago
  metodo_pago     metodo_pago,
  fecha_pago      TIMESTAMPTZ,
  -- Control
  notas           TEXT,
  vendedor_id     UUID            REFERENCES usuarios(id) ON DELETE SET NULL,
  creado_en       TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  actualizado_en  TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE SEQUENCE seq_venta START 1;

CREATE TABLE ventas_items (
  id              UUID           PRIMARY KEY DEFAULT uuid_generate_v4(),
  venta_id        UUID           NOT NULL REFERENCES ventas(id) ON DELETE CASCADE,
  producto_id     UUID           NOT NULL REFERENCES productos(id),
  variante_id     UUID           REFERENCES producto_variantes(id),
  lote_id         UUID           REFERENCES lotes(id),  -- FIFO: lote seleccionado
  cantidad        INTEGER        NOT NULL,
  precio_unitario NUMERIC(12,2)  NOT NULL,
  descuento_pct   NUMERIC(5,2)   DEFAULT 0,
  subtotal        NUMERIC(12,2)  NOT NULL
);

CREATE INDEX idx_ventas_fecha ON ventas(fecha);
CREATE INDEX idx_ventas_cliente ON ventas(cliente_id);
CREATE INDEX idx_ventas_estado ON ventas(estado);

-- ============================================================
--  ALERTAS AUTOMÁTICAS
-- ============================================================

CREATE TYPE tipo_alerta AS ENUM (
  'stock_bajo', 'sin_stock', 'proximo_vencimiento', 'vencido', 'pago_proveedor'
);

CREATE TABLE alertas (
  id              BIGSERIAL PRIMARY KEY,
  tipo            tipo_alerta  NOT NULL,
  titulo          VARCHAR(200) NOT NULL,
  descripcion     TEXT,
  referencia_tipo VARCHAR(50),
  referencia_id   UUID,
  resuelta        BOOLEAN      NOT NULL DEFAULT FALSE,
  resuelta_por    UUID         REFERENCES usuarios(id) ON DELETE SET NULL,
  resuelta_en     TIMESTAMPTZ,
  creado_en       TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ============================================================
--  FUNCIONES Y TRIGGERS
-- ============================================================

-- Actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION fn_actualizar_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.actualizado_en = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_usuarios_updated BEFORE UPDATE ON usuarios
  FOR EACH ROW EXECUTE FUNCTION fn_actualizar_timestamp();
CREATE TRIGGER trg_productos_updated BEFORE UPDATE ON productos
  FOR EACH ROW EXECUTE FUNCTION fn_actualizar_timestamp();
CREATE TRIGGER trg_lotes_updated BEFORE UPDATE ON lotes
  FOR EACH ROW EXECUTE FUNCTION fn_actualizar_timestamp();
CREATE TRIGGER trg_proveedores_updated BEFORE UPDATE ON proveedores
  FOR EACH ROW EXECUTE FUNCTION fn_actualizar_timestamp();
CREATE TRIGGER trg_ordenes_updated BEFORE UPDATE ON ordenes_compra
  FOR EACH ROW EXECUTE FUNCTION fn_actualizar_timestamp();
CREATE TRIGGER trg_ventas_updated BEFORE UPDATE ON ventas
  FOR EACH ROW EXECUTE FUNCTION fn_actualizar_timestamp();

-- Generar alertas de stock bajo automáticamente
CREATE OR REPLACE FUNCTION fn_alerta_stock_bajo()
RETURNS TRIGGER AS $$
DECLARE
  prod RECORD;
  stock_disp INTEGER;
BEGIN
  SELECT p.nombre, p.stock_minimo,
    COALESCE(SUM(l2.stock_actual), 0) - COALESCE(SUM(l2.stock_reservado), 0) AS disponible
  INTO prod
  FROM productos p
  LEFT JOIN lotes l2 ON l2.producto_id = p.id AND l2.activo = TRUE
  WHERE p.id = NEW.producto_id
  GROUP BY p.id, p.nombre, p.stock_minimo;

  IF prod.disponible <= 0 THEN
    INSERT INTO alertas (tipo, titulo, descripcion, referencia_tipo, referencia_id)
    VALUES ('sin_stock', 'Sin stock: ' || prod.nombre,
            'El producto quedó sin stock disponible.',
            'producto', NEW.producto_id)
    ON CONFLICT DO NOTHING;
  ELSIF prod.disponible <= prod.stock_minimo THEN
    INSERT INTO alertas (tipo, titulo, descripcion, referencia_tipo, referencia_id)
    VALUES ('stock_bajo', 'Stock bajo: ' || prod.nombre,
            'Stock disponible (' || prod.disponible || ') por debajo del mínimo (' || prod.stock_minimo || ').',
            'producto', NEW.producto_id)
    ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_alerta_stock
  AFTER UPDATE OF stock_actual ON lotes
  FOR EACH ROW EXECUTE FUNCTION fn_alerta_stock_bajo();

-- Numeración automática de ventas y órdenes de compra
CREATE OR REPLACE FUNCTION fn_numero_venta()
RETURNS TRIGGER AS $$
BEGIN
  NEW.numero = 'V-' || LPAD(nextval('seq_venta')::TEXT, 6, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION fn_numero_oc()
RETURNS TRIGGER AS $$
BEGIN
  NEW.numero = 'OC-' || LPAD(nextval('seq_oc')::TEXT, 4, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_numero_venta BEFORE INSERT ON ventas
  FOR EACH ROW EXECUTE FUNCTION fn_numero_venta();
CREATE TRIGGER trg_numero_oc BEFORE INSERT ON ordenes_compra
  FOR EACH ROW EXECUTE FUNCTION fn_numero_oc();

-- ============================================================
--  DATOS INICIALES: USUARIO ADMIN
-- ============================================================

INSERT INTO usuarios (nombre, apellido, email, password_hash, rol)
VALUES ('Admin', 'Sistema', 'admin@erp.local',
        '$2b$12$placeholder_hash_reemplazar_con_bcrypt', 'admin');

INSERT INTO categorias (nombre, descripcion, tiene_vencimiento) VALUES
  ('Indumentaria',  'Ropa en general',           FALSE),
  ('Calzado',       'Zapatos y zapatillas',       FALSE),
  ('Accesorios',    'Cinturones, bolsos, etc.',   FALSE),
  ('Alimentos',     'Productos alimenticios',     TRUE),
  ('Cosmética',     'Perfumes y cuidado personal',TRUE);
