const jwt = require('jsonwebtoken');
const { query } = require('../config/db');

const autenticar = async (req, res, next) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token requerido.' });
  }
  const token = header.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const { rows } = await query(
      'SELECT id, nombre, apellido, email, rol, activo FROM usuarios WHERE id = $1',
      [decoded.id]
    );
    if (!rows.length || !rows[0].activo) {
      return res.status(401).json({ error: 'Usuario no autorizado.' });
    }
    req.usuario = rows[0];
    next();
  } catch {
    return res.status(401).json({ error: 'Token inválido o expirado.' });
  }
};

const autorizar = (...roles) => (req, res, next) => {
  if (!roles.includes(req.usuario.rol)) {
    return res.status(403).json({ error: 'Sin permisos para esta acción.' });
  }
  next();
};

module.exports = { autenticar, autorizar };
