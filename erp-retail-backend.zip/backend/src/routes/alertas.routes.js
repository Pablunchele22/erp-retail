const express = require('express');
const r = express.Router();
const { autenticar, autorizar } = require('../middlewares/auth.middleware');
const { query } = require('../config/db');

r.use(autenticar);

r.get('/', async (req, res, next) => {
  try {
    const { resuelta = 'false', tipo } = req.query;
    let conds = [`a.resuelta = $1`], params = [resuelta === 'true'], i = 2;
    if (tipo) { conds.push(`a.tipo = $${i++}`); params.push(tipo); }
    const { rows } = await query(
      `SELECT a.*, u.nombre || ' ' || u.apellido AS resuelta_por_nombre
       FROM alertas a LEFT JOIN usuarios u ON u.id = a.resuelta_por
       WHERE ${conds.join(' AND ')}
       ORDER BY a.creado_en DESC LIMIT 100`, params
    );
    res.json({ alertas: rows });
  } catch (err) { next(err); }
});

r.patch('/:id/resolver', async (req, res, next) => {
  try {
    const { rows } = await query(
      `UPDATE alertas SET resuelta = TRUE, resuelta_por = $1, resuelta_en = NOW()
       WHERE id = $2 RETURNING *`,
      [req.usuario.id, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Alerta no encontrada.' });
    res.json({ alerta: rows[0] });
  } catch (err) { next(err); }
});

module.exports = r;
