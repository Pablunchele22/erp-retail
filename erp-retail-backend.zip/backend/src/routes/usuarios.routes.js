const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/usuarios.controller');
const { autenticar, autorizar } = require('../middlewares/auth.middleware');

router.use(autenticar);

router.get('/',                          autorizar('admin'), ctrl.listar);
router.get('/:id',                       autorizar('admin'), ctrl.obtener);
router.post('/',                         autorizar('admin'), ctrl.crear);
router.put('/:id',                       autorizar('admin'), ctrl.actualizar);
router.post('/:id/reset-password',       autorizar('admin'), ctrl.resetPassword);
router.get('/:id/auditoria',             autorizar('admin'), ctrl.obtenerAuditoria);

module.exports = router;
