// routes/auth.routes.js
const express = require('express');
const router = express.Router();
const { login, me, cambiarPassword } = require('../controllers/auth.controller');
const { autenticar } = require('../middlewares/auth.middleware');

router.post('/login', login);
router.get('/me', autenticar, me);
router.post('/cambiar-password', autenticar, cambiarPassword);

module.exports = router;
