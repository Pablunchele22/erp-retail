// ── productos.routes.js ─────────────────────────────────────
const express  = require('express');
const router   = express.Router();
const ctrl     = require('../controllers/productos.controller');
const { autenticar, autorizar } = require('../middlewares/auth.middleware');

router.use(autenticar);
router.get('/categorias', ctrl.listarCategorias);
router.get('/',    ctrl.listar);
router.get('/:id', ctrl.obtener);
router.post('/',   autorizar('admin', 'deposito'), ctrl.crear);
router.put('/:id', autorizar('admin', 'deposito'), ctrl.actualizar);

module.exports = router;
