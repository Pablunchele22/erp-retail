// lotes.routes.js
const express = require('express');
const r1 = express.Router();
const lCtrl = require('../controllers/lotes.controller');
const { autenticar, autorizar } = require('../middlewares/auth.middleware');
r1.use(autenticar);
r1.get('/',          lCtrl.listar);
r1.post('/',         autorizar('admin','deposito','compras'), lCtrl.crear);
r1.post('/ajuste',   autorizar('admin','deposito'), lCtrl.ajustarStock);
module.exports = r1;
