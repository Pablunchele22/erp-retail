// proveedores.routes.js
const express = require('express');
const r = express.Router();
const ctrl = require('../controllers/proveedores.controller');
const { autenticar, autorizar } = require('../middlewares/auth.middleware');
r.use(autenticar);
r.get('/',    ctrl.listar);
r.get('/:id', ctrl.obtener);
r.post('/',   autorizar('admin','compras'), ctrl.crear);
r.put('/:id', autorizar('admin','compras'), ctrl.actualizar);
module.exports = r;
