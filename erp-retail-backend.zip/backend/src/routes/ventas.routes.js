// ventas.routes.js
const express = require('express');
const r = express.Router();
const ctrl = require('../controllers/ventas.controller');
const { autenticar, autorizar } = require('../middlewares/auth.middleware');
r.use(autenticar);
r.get('/',          ctrl.listar);
r.get('/:id',       ctrl.obtener);
r.post('/',         autorizar('admin','vendedor'), ctrl.crear);
r.patch('/:id/estado', autorizar('admin','vendedor'), ctrl.cambiarEstado);
module.exports = r;
