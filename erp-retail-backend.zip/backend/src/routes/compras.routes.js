// compras.routes.js
const express = require('express');
const r = express.Router();
const { autenticar, autorizar } = require('../middlewares/auth.middleware');
const { query } = require('../config/db');

r.use(autenticar);

r.get('/', async (req, res, next) => {
  try {
    const { estado, proveedor_id } = req.query;
    let conds = [], params = [], i = 1;
    if (estado)      { conds.push(`oc.estado = $${i++}`);       params.push(estado); }
    if (proveedor_id){ conds.push(`oc.proveedor_id = $${i++}`); params.push(proveedor_id); }
    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';
    const { rows } = await query(
      `SELECT oc.id, oc.numero, oc.estado, oc.fecha_emision, oc.fecha_esperada,
              oc.total, oc.moneda, pr.razon_social AS proveedor,
              u.nombre || ' ' || u.apellido AS creado_por,
              COUNT(oci.id) AS items
       FROM ordenes_compra oc
       JOIN proveedores pr ON pr.id = oc.proveedor_id
       LEFT JOIN usuarios u ON u.id = oc.creado_por
       LEFT JOIN ordenes_compra_items oci ON oci.orden_compra_id = oc.id
       ${where}
       GROUP BY oc.id, pr.razon_social, u.nombre, u.apellido
       ORDER BY oc.creado_en DESC`, params
    );
    res.json({ ordenes: rows });
  } catch (err) { next(err); }
});

r.get('/:id', async (req, res, next) => {
  try {
    const { rows: oc } = await query(
      `SELECT oc.*, pr.razon_social AS proveedor, pr.dias_pago
       FROM ordenes_compra oc JOIN proveedores pr ON pr.id = oc.proveedor_id
       WHERE oc.id = $1`, [req.params.id]
    );
    if (!oc.length) return res.status(404).json({ error: 'Orden no encontrada.' });
    const { rows: items } = await query(
      `SELECT oci.*, p.nombre AS producto, p.sku
       FROM ordenes_compra_items oci JOIN productos p ON p.id = oci.producto_id
       WHERE oci.orden_compra_id = $1`, [req.params.id]
    );
    res.json({ orden: oc[0], items });
  } catch (err) { next(err); }
});

r.post('/', autorizar('admin','compras'), async (req, res, next) => {
  try {
    const { proveedor_id, items, fecha_esperada, notas } = req.body;
    if (!proveedor_id || !items?.length) {
      return res.status(400).json({ error: 'Proveedor e items requeridos.' });
    }
    let subtotal = 0;
    const { rows: oc } = await query(
      `INSERT INTO ordenes_compra (proveedor_id, fecha_esperada, subtotal, total, notas, creado_por)
       VALUES ($1, $2, 0, 0, $3, $4) RETURNING *`,
      [proveedor_id, fecha_esperada||null, notas||null, req.usuario.id]
    );
    for (const item of items) {
      const itemSub = item.cantidad_pedida * item.precio_unitario;
      subtotal += itemSub;
      await query(
        `INSERT INTO ordenes_compra_items
         (orden_compra_id, producto_id, variante_id, cantidad_pedida, precio_unitario, subtotal, numero_lote, fecha_vencimiento, notas)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [oc[0].id, item.producto_id, item.variante_id||null, item.cantidad_pedida,
         item.precio_unitario, itemSub, item.numero_lote||null, item.fecha_vencimiento||null, item.notas||null]
      );
    }
    const total = subtotal * 1.22;
    await query('UPDATE ordenes_compra SET subtotal = $1, total = $2 WHERE id = $3', [subtotal, total, oc[0].id]);
    res.status(201).json({ orden: { ...oc[0], subtotal, total } });
  } catch (err) { next(err); }
});

r.patch('/:id/estado', autorizar('admin','compras'), async (req, res, next) => {
  try {
    const estadosValidos = ['enviada','confirmada','en_transito','recibida','cancelada'];
    if (!estadosValidos.includes(req.body.estado)) {
      return res.status(400).json({ error: 'Estado inválido.' });
    }
    const { rows } = await query(
      'UPDATE ordenes_compra SET estado = $1 WHERE id = $2 RETURNING id, numero, estado',
      [req.body.estado, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Orden no encontrada.' });
    res.json({ orden: rows[0] });
  } catch (err) { next(err); }
});

module.exports = r;
