const { query, getClient } = require('../config/db');

// GET /api/ventas
const listar = async (req, res, next) => {
  try {
    const { estado, cliente_id, desde, hasta, page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    let conditions = [];
    let params = [];
    let i = 1;

    if (estado)     { conditions.push(`v.estado = $${i++}`);      params.push(estado); }
    if (cliente_id) { conditions.push(`v.cliente_id = $${i++}`);  params.push(cliente_id); }
    if (desde)      { conditions.push(`v.fecha >= $${i++}`);      params.push(desde); }
    if (hasta)      { conditions.push(`v.fecha <= $${i++}`);      params.push(hasta); }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const { rows } = await query(
      `SELECT v.id, v.numero, v.estado, v.fecha, v.total, v.metodo_pago,
              c.nombre AS cliente, u.nombre || ' ' || u.apellido AS vendedor
       FROM ventas v
       LEFT JOIN clientes c ON c.id = v.cliente_id
       LEFT JOIN usuarios u ON u.id = v.vendedor_id
       ${where}
       ORDER BY v.creado_en DESC
       LIMIT $${i} OFFSET $${i+1}`,
      [...params, parseInt(limit), offset]
    );
    res.json({ ventas: rows });
  } catch (err) { next(err); }
};

// GET /api/ventas/:id
const obtener = async (req, res, next) => {
  try {
    const { rows: v } = await query(
      `SELECT v.*, c.nombre AS cliente, c.documento, c.email AS cliente_email,
              u.nombre || ' ' || u.apellido AS vendedor
       FROM ventas v
       LEFT JOIN clientes c ON c.id = v.cliente_id
       LEFT JOIN usuarios u ON u.id = v.vendedor_id
       WHERE v.id = $1`,
      [req.params.id]
    );
    if (!v.length) return res.status(404).json({ error: 'Venta no encontrada.' });

    const { rows: items } = await query(
      `SELECT vi.*, p.nombre AS producto, p.sku,
              pv.talla, pv.color, l.numero_lote
       FROM ventas_items vi
       JOIN productos p ON p.id = vi.producto_id
       LEFT JOIN producto_variantes pv ON pv.id = vi.variante_id
       LEFT JOIN lotes l ON l.id = vi.lote_id
       WHERE vi.venta_id = $1`,
      [req.params.id]
    );

    res.json({ venta: v[0], items });
  } catch (err) { next(err); }
};

// POST /api/ventas
const crear = async (req, res, next) => {
  try {
    const { cliente_id, items, metodo_pago, descuento_pct, notas } = req.body;
    if (!items?.length) return res.status(400).json({ error: 'La venta debe tener al menos un item.' });

    const client = await getClient();
    try {
      await client.query('BEGIN');

      // Calcular totales
      let subtotal = 0;
      const itemsProcesados = [];

      for (const item of items) {
        const { producto_id, variante_id, cantidad } = item;

        // Obtener precio de venta
        const { rows: prod } = await client.query(
          'SELECT precio_venta, precio_mayorista FROM productos WHERE id = $1 AND activo = TRUE',
          [producto_id]
        );
        if (!prod.length) throw { status: 400, message: `Producto ${producto_id} no encontrado.` };

        // FIFO: obtener lotes más antiguos primero, priorizando los de menor vencimiento
        const { rows: lotes } = await client.query(
          `SELECT id, stock_actual, stock_reservado
           FROM lotes
           WHERE producto_id = $1
             AND ($2::uuid IS NULL OR variante_id = $2)
             AND activo = TRUE
             AND (stock_actual - stock_reservado) > 0
           ORDER BY fecha_vencimiento ASC NULLS LAST, fecha_recibido ASC
           FOR UPDATE`,
          [producto_id, variante_id || null]
        );

        const stockTotal = lotes.reduce((acc, l) => acc + l.stock_actual - l.stock_reservado, 0);
        if (stockTotal < cantidad) {
          throw { status: 400, message: `Stock insuficiente para producto ${prod[0]?.nombre || producto_id}. Disponible: ${stockTotal}` };
        }

        // Descontar FIFO
        let restante = cantidad;
        const lotesUsados = [];
        for (const lote of lotes) {
          if (restante <= 0) break;
          const disponible = lote.stock_actual - lote.stock_reservado;
          const aDescontar = Math.min(disponible, restante);
          lotesUsados.push({ lote_id: lote.id, cantidad: aDescontar });
          restante -= aDescontar;
        }

        const precio_unitario = item.precio_unitario || prod[0].precio_venta;
        const itemSubtotal = precio_unitario * cantidad;
        subtotal += itemSubtotal;
        itemsProcesados.push({ producto_id, variante_id, lote_id: lotesUsados[0]?.lote_id, cantidad, precio_unitario, subtotal: itemSubtotal, lotesUsados });
      }

      const descuento = (subtotal * (parseFloat(descuento_pct) || 0)) / 100;
      const base = subtotal - descuento;
      const impuesto = base * 0.22;
      const total = base + impuesto;

      // Insertar venta
      const { rows: venta } = await client.query(
        `INSERT INTO ventas (cliente_id, estado, subtotal, descuento_pct, descuento_monto, total, metodo_pago, notas, vendedor_id)
         VALUES ($1, 'confirmada', $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
        [cliente_id || null, subtotal, descuento_pct || 0, descuento, total, metodo_pago || null, notas || null, req.usuario.id]
      );

      // Insertar items y descontar stock
      for (const item of itemsProcesados) {
        await client.query(
          `INSERT INTO ventas_items (venta_id, producto_id, variante_id, lote_id, cantidad, precio_unitario, subtotal)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [venta[0].id, item.producto_id, item.variante_id, item.lote_id, item.cantidad, item.precio_unitario, item.subtotal]
        );

        // Descontar stock FIFO
        for (const { lote_id, cantidad } of item.lotesUsados) {
          const { rows: loteActual } = await client.query(
            'SELECT stock_actual FROM lotes WHERE id = $1', [lote_id]
          );
          const nuevoStock = loteActual[0].stock_actual - cantidad;
          await client.query('UPDATE lotes SET stock_actual = $1 WHERE id = $2', [nuevoStock, lote_id]);
          await client.query(
            `INSERT INTO movimientos_inventario
             (lote_id, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, usuario_id)
             VALUES ($1, 'salida_venta', $2, $3, $4, 'venta', $5, $6)`,
            [lote_id, cantidad, loteActual[0].stock_actual, nuevoStock, venta[0].id, req.usuario.id]
          );
        }
      }

      await client.query('COMMIT');
      res.status(201).json({ venta: venta[0] });
    } catch (e) {
      await client.query('ROLLBACK');
      if (e.status) return res.status(e.status).json({ error: e.message });
      throw e;
    } finally {
      client.release();
    }
  } catch (err) { next(err); }
};

// PATCH /api/ventas/:id/estado
const cambiarEstado = async (req, res, next) => {
  try {
    const { estado } = req.body;
    const estadosValidos = ['pagada', 'cancelada', 'devuelta'];
    if (!estadosValidos.includes(estado)) {
      return res.status(400).json({ error: 'Estado inválido.' });
    }
    const { rows } = await query(
      'UPDATE ventas SET estado = $1 WHERE id = $2 RETURNING id, numero, estado',
      [estado, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Venta no encontrada.' });
    res.json({ venta: rows[0] });
  } catch (err) { next(err); }
};

module.exports = { listar, obtener, crear, cambiarEstado };
