const bcrypt  = require('bcryptjs');
const { query } = require('../config/db');

// GET /api/usuarios
const listar = async (req, res, next) => {
  try {
    const { activo, rol, buscar } = req.query;
    let conditions = [];
    let params = [];
    let i = 1;

    if (activo !== undefined) {
      conditions.push(`u.activo = $${i++}`);
      params.push(activo === 'true');
    }
    if (rol) {
      conditions.push(`u.rol = $${i++}`);
      params.push(rol);
    }
    if (buscar) {
      conditions.push(`(u.nombre ILIKE $${i} OR u.apellido ILIKE $${i} OR u.email ILIKE $${i})`);
      params.push(`%${buscar}%`);
      i++;
    }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const { rows } = await query(
      `SELECT u.id, u.nombre, u.apellido, u.email, u.rol, u.activo,
              u.ultimo_acceso, u.creado_en
       FROM usuarios u
       ${where}
       ORDER BY u.creado_en DESC`,
      params
    );
    res.json({ usuarios: rows });
  } catch (err) {
    next(err);
  }
};

// GET /api/usuarios/:id
const obtener = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT id, nombre, apellido, email, rol, activo, ultimo_acceso, creado_en
       FROM usuarios WHERE id = $1`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Usuario no encontrado.' });
    res.json({ usuario: rows[0] });
  } catch (err) {
    next(err);
  }
};

// POST /api/usuarios  (solo admin)
const crear = async (req, res, next) => {
  try {
    const { nombre, apellido, email, password, rol } = req.body;
    if (!nombre || !apellido || !email || !password) {
      return res.status(400).json({ error: 'Nombre, apellido, email y contraseña son requeridos.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'La contraseña debe tener al menos 8 caracteres.' });
    }

    const rolesValidos = ['admin', 'vendedor', 'deposito', 'compras'];
    if (rol && !rolesValidos.includes(rol)) {
      return res.status(400).json({ error: 'Rol inválido.' });
    }

    const hash = await bcrypt.hash(password, 12);
    const { rows } = await query(
      `INSERT INTO usuarios (nombre, apellido, email, password_hash, rol)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, nombre, apellido, email, rol, activo, creado_en`,
      [nombre.trim(), apellido.trim(), email.toLowerCase().trim(), hash, rol || 'vendedor']
    );

    await query(
      'INSERT INTO auditoria (usuario_id, accion, tabla, registro_id) VALUES ($1, $2, $3, $4)',
      [req.usuario.id, 'CREAR_USUARIO', 'usuarios', rows[0].id]
    );

    res.status(201).json({ usuario: rows[0] });
  } catch (err) {
    next(err);
  }
};

// PUT /api/usuarios/:id  (solo admin)
const actualizar = async (req, res, next) => {
  try {
    const { nombre, apellido, email, rol, activo } = req.body;
    const { id } = req.params;

    const { rows: existente } = await query('SELECT id FROM usuarios WHERE id = $1', [id]);
    if (!existente.length) return res.status(404).json({ error: 'Usuario no encontrado.' });

    const { rows } = await query(
      `UPDATE usuarios SET
        nombre    = COALESCE($1, nombre),
        apellido  = COALESCE($2, apellido),
        email     = COALESCE($3, email),
        rol       = COALESCE($4, rol),
        activo    = COALESCE($5, activo)
       WHERE id = $6
       RETURNING id, nombre, apellido, email, rol, activo`,
      [
        nombre?.trim() || null,
        apellido?.trim() || null,
        email?.toLowerCase().trim() || null,
        rol || null,
        activo !== undefined ? activo : null,
        id,
      ]
    );

    await query(
      'INSERT INTO auditoria (usuario_id, accion, tabla, registro_id) VALUES ($1, $2, $3, $4)',
      [req.usuario.id, 'ACTUALIZAR_USUARIO', 'usuarios', id]
    );

    res.json({ usuario: rows[0] });
  } catch (err) {
    next(err);
  }
};

// POST /api/usuarios/:id/reset-password  (solo admin)
const resetPassword = async (req, res, next) => {
  try {
    const { password_nueva } = req.body;
    if (!password_nueva || password_nueva.length < 8) {
      return res.status(400).json({ error: 'La contraseña debe tener al menos 8 caracteres.' });
    }

    const hash = await bcrypt.hash(password_nueva, 12);
    const { rowCount } = await query(
      'UPDATE usuarios SET password_hash = $1 WHERE id = $2',
      [hash, req.params.id]
    );
    if (!rowCount) return res.status(404).json({ error: 'Usuario no encontrado.' });

    await query(
      'INSERT INTO auditoria (usuario_id, accion, tabla, registro_id, detalle) VALUES ($1, $2, $3, $4, $5)',
      [req.usuario.id, 'RESET_PASSWORD', 'usuarios', req.params.id,
       JSON.stringify({ resetado_por: req.usuario.email })]
    );

    res.json({ mensaje: 'Contraseña reseteada correctamente.' });
  } catch (err) {
    next(err);
  }
};

// GET /api/usuarios/:id/auditoria
const obtenerAuditoria = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT a.id, a.accion, a.tabla, a.registro_id, a.detalle, a.ip, a.creado_en
       FROM auditoria a
       WHERE a.usuario_id = $1
       ORDER BY a.creado_en DESC
       LIMIT 50`,
      [req.params.id]
    );
    res.json({ auditoria: rows });
  } catch (err) {
    next(err);
  }
};

module.exports = { listar, obtener, crear, actualizar, resetPassword, obtenerAuditoria };
