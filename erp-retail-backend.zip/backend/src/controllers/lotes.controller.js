const { query, getClient } = require('../config/db');

// GET /api/lotes?producto_id=...
const listar = async (req, res, next) => {
  try {
    const { producto_id, proximos_vencer, dias = 30 } = req.query;
    let conditions = ['l.activo = TRUE'];
    let params = [];
    let i = 1;

    if (producto_id) { conditions.push(`l.producto_id = $${i++}`); params.push(producto_id); }
    if (proximos_vencer === 'true') {
      conditions.push(`l.fecha_vencimiento IS NOT NULL AND l.fecha_vencimiento <= NOW() + INTERVAL '${parseInt(dias)} days'`);
    }

    const { rows } = await query(
      `SELECT l.*, p.nombre AS producto, p.sku,
              pr.razon_social AS proveedor,
              oc.numero AS orden_compra
       FROM lotes l
       JOIN productos p ON p.id = l.producto_id
       LEFT JOIN proveedores pr ON pr.id = l.proveedor_id
       LEFT JOIN ordenes_compra oc ON oc.id = l.orden_compra_id
       WHERE ${conditions.join(' AND ')}
       ORDER BY l.fecha_vencimiento ASC NULLS LAST, l.fecha_recibido ASC`,
      params
    );
    res.json({ lotes: rows });
  } catch (err) { next(err); }
};

// POST /api/lotes
const crear = async (req, res, next) => {
  try {
    const {
      producto_id, variante_id, numero_lote, numero_serie,
      fecha_fabricacion, fecha_vencimiento, fecha_recibido,
      stock_inicial, proveedor_id, orden_compra_id
    } = req.body;

    if (!producto_id || !numero_lote || stock_inicial === undefined) {
      return res.status(400).json({ error: 'Producto, número de lote y stock inicial son requeridos.' });
    }

    // Verificar si la categoría requiere vencimiento
    const { rows: cat } = await query(
      `SELECT c.tiene_vencimiento FROM productos p
       JOIN categorias c ON c.id = p.categoria_id
       WHERE p.id = $1`,
      [producto_id]
    );
    if (cat.length && cat[0].tiene_vencimiento && !fecha_vencimiento) {
      return res.status(400).json({ error: 'Esta categoría requiere fecha de vencimiento.' });
    }

    const client = await getClient();
    try {
      await client.query('BEGIN');

      const { rows } = await client.query(
        `INSERT INTO lotes (
          producto_id, variante_id, numero_lote, numero_serie,
          fecha_fabricacion, fecha_vencimiento, fecha_recibido,
          stock_inicial, stock_actual, proveedor_id, orden_compra_id, creado_por
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8,$9,$10,$11) RETURNING *`,
        [
          producto_id, variante_id || null, numero_lote, numero_serie || null,
          fecha_fabricacion || null, fecha_vencimiento || null,
          fecha_recibido || new Date().toISOString().split('T')[0],
          stock_inicial, proveedor_id || null, orden_compra_id || null,
          req.usuario.id,
        ]
      );

      // Registrar movimiento de entrada
      await client.query(
        `INSERT INTO movimientos_inventario
         (lote_id, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, usuario_id)
         VALUES ($1, 'entrada_compra', $2, 0, $2, $3, $4, $5)`,
        [rows[0].id, stock_inicial, orden_compra_id ? 'orden_compra' : 'ajuste',
         orden_compra_id || null, req.usuario.id]
      );

      await client.query('COMMIT');
      res.status(201).json({ lote: rows[0] });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  } catch (err) { next(err); }
};

// POST /api/lotes/ajuste — ajuste manual de stock
const ajustarStock = async (req, res, next) => {
  try {
    const { lote_id, cantidad, tipo, motivo } = req.body;
    const tiposValidos = ['ajuste_positivo', 'ajuste_negativo', 'merma', 'rotura', 'devolucion_cliente'];
    if (!lote_id || !cantidad || !tipo || !tiposValidos.includes(tipo)) {
      return res.status(400).json({ error: 'Datos de ajuste inválidos.' });
    }

    const client = await getClient();
    try {
      await client.query('BEGIN');

      const { rows: lote } = await client.query(
        'SELECT stock_actual FROM lotes WHERE id = $1 FOR UPDATE', [lote_id]
      );
      if (!lote.length) return res.status(404).json({ error: 'Lote no encontrado.' });

      const delta = tipo === 'ajuste_negativo' || tipo === 'merma' || tipo === 'rotura'
        ? -Math.abs(cantidad) : Math.abs(cantidad);
      const nuevoStock = lote[0].stock_actual + delta;

      if (nuevoStock < 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'El ajuste dejaría el stock en negativo.' });
      }

      await client.query(
        'UPDATE lotes SET stock_actual = $1 WHERE id = $2', [nuevoStock, lote_id]
      );
      await client.query(
        `INSERT INTO movimientos_inventario
         (lote_id, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, motivo, usuario_id)
         VALUES ($1, $2, $3, $4, $5, 'ajuste', $6, $7)`,
        [lote_id, tipo, Math.abs(cantidad), lote[0].stock_actual, nuevoStock, motivo || null, req.usuario.id]
      );

      await client.query('COMMIT');
      res.json({ lote_id, stock_anterior: lote[0].stock_actual, stock_nuevo: nuevoStock });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  } catch (err) { next(err); }
};

module.exports = { listar, crear, ajustarStock };
