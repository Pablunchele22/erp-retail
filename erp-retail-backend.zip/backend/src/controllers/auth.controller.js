const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const { query } = require('../config/db');

const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email y contraseña requeridos.' });
    }

    const { rows } = await query(
      'SELECT * FROM usuarios WHERE email = $1 AND activo = TRUE',
      [email.toLowerCase().trim()]
    );

    if (!rows.length || !(await bcrypt.compare(password, rows[0].password_hash))) {
      return res.status(401).json({ error: 'Credenciales incorrectas.' });
    }

    const usuario = rows[0];
    const token = jwt.sign(
      { id: usuario.id, rol: usuario.rol },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    // Registrar último acceso
    await query('UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = $1', [usuario.id]);

    // Auditoría
    await query(
      'INSERT INTO auditoria (usuario_id, accion, ip) VALUES ($1, $2, $3)',
      [usuario.id, 'LOGIN', req.ip]
    );

    res.json({
      token,
      usuario: {
        id:       usuario.id,
        nombre:   usuario.nombre,
        apellido: usuario.apellido,
        email:    usuario.email,
        rol:      usuario.rol,
      },
    });
  } catch (err) {
    next(err);
  }
};

const me = async (req, res) => {
  res.json({ usuario: req.usuario });
};

const cambiarPassword = async (req, res, next) => {
  try {
    const { password_actual, password_nueva } = req.body;
    if (!password_actual || !password_nueva || password_nueva.length < 8) {
      return res.status(400).json({ error: 'Contraseña nueva debe tener al menos 8 caracteres.' });
    }

    const { rows } = await query('SELECT password_hash FROM usuarios WHERE id = $1', [req.usuario.id]);
    if (!(await bcrypt.compare(password_actual, rows[0].password_hash))) {
      return res.status(401).json({ error: 'Contraseña actual incorrecta.' });
    }

    const hash = await bcrypt.hash(password_nueva, 12);
    await query('UPDATE usuarios SET password_hash = $1 WHERE id = $2', [hash, req.usuario.id]);

    res.json({ mensaje: 'Contraseña actualizada correctamente.' });
  } catch (err) {
    next(err);
  }
};

module.exports = { login, me, cambiarPassword };
