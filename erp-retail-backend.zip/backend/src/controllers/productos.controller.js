const { query } = require('../config/db');

// GET /api/productos
const listar = async (req, res, next) => {
  try {
    const { categoria_id, marca_id, buscar, stock_bajo, activo = 'true', page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    let conditions = [`p.activo = $1`];
    let params = [activo === 'true'];
    let i = 2;

    if (categoria_id) { conditions.push(`p.categoria_id = $${i++}`); params.push(categoria_id); }
    if (marca_id)     { conditions.push(`p.marca_id = $${i++}`);     params.push(marca_id); }
    if (buscar) {
      conditions.push(`(p.nombre ILIKE $${i} OR p.sku ILIKE $${i} OR p.codigo_barras ILIKE $${i})`);
      params.push(`%${buscar}%`); i++;
    }
    if (stock_bajo === 'true') {
      conditions.push(`(SELECT COALESCE(SUM(l.stock_actual),0) FROM lotes l WHERE l.producto_id = p.id AND l.activo = TRUE) <= p.stock_minimo`);
    }

    const where = 'WHERE ' + conditions.join(' AND ');
    const { rows } = await query(
      `SELECT p.id, p.sku, p.codigo_barras, p.nombre, p.precio_costo, p.precio_venta,
              p.stock_minimo, p.activo, p.tiene_variantes,
              c.nombre AS categoria, m.nombre AS marca, u.simbolo AS unidad,
              COALESCE(SUM(l.stock_actual), 0) AS stock_total,
              COALESCE(SUM(l.stock_actual), 0) - COALESCE(SUM(l.stock_reservado), 0) AS stock_disponible,
              MIN(l.fecha_vencimiento) FILTER (WHERE l.fecha_vencimiento IS NOT NULL) AS proximo_vencimiento
       FROM productos p
       LEFT JOIN categorias c ON c.id = p.categoria_id
       LEFT JOIN marcas m ON m.id = p.marca_id
       LEFT JOIN unidades_medida u ON u.id = p.unidad_medida_id
       LEFT JOIN lotes l ON l.producto_id = p.id AND l.activo = TRUE
       ${where}
       GROUP BY p.id, c.nombre, m.nombre, u.simbolo
       ORDER BY p.nombre
       LIMIT $${i} OFFSET $${i+1}`,
      [...params, parseInt(limit), offset]
    );
    res.json({ productos: rows, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) { next(err); }
};

// GET /api/productos/:id
const obtener = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT p.*, c.nombre AS categoria, c.tiene_vencimiento,
              m.nombre AS marca, u.nombre AS unidad_medida
       FROM productos p
       LEFT JOIN categorias c ON c.id = p.categoria_id
       LEFT JOIN marcas m ON m.id = p.marca_id
       LEFT JOIN unidades_medida u ON u.id = p.unidad_medida_id
       WHERE p.id = $1`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Producto no encontrado.' });

    const { rows: variantes } = await query(
      'SELECT * FROM producto_variantes WHERE producto_id = $1 AND activa = TRUE',
      [req.params.id]
    );
    const { rows: lotes } = await query(
      `SELECT l.*, pr.razon_social AS proveedor
       FROM lotes l
       LEFT JOIN proveedores pr ON pr.id = l.proveedor_id
       WHERE l.producto_id = $1 AND l.activo = TRUE
       ORDER BY l.fecha_vencimiento ASC NULLS LAST, l.fecha_recibido ASC`,
      [req.params.id]
    );

    res.json({ producto: rows[0], variantes, lotes });
  } catch (err) { next(err); }
};

// POST /api/productos
const crear = async (req, res, next) => {
  try {
    const {
      sku, codigo_barras, nombre, descripcion, categoria_id, marca_id,
      unidad_medida_id, precio_costo, precio_venta, precio_mayorista,
      moneda, stock_minimo, stock_maximo, ubicacion_deposito,
      tiene_variantes, pais_origen, unidad_compra, dias_entrega_prov
    } = req.body;

    if (!sku || !nombre || precio_venta === undefined) {
      return res.status(400).json({ error: 'SKU, nombre y precio de venta son requeridos.' });
    }

    const { rows } = await query(
      `INSERT INTO productos (
        sku, codigo_barras, nombre, descripcion, categoria_id, marca_id,
        unidad_medida_id, precio_costo, precio_venta, precio_mayorista,
        moneda, stock_minimo, stock_maximo, ubicacion_deposito,
        tiene_variantes, pais_origen, unidad_compra, dias_entrega_prov, creado_por
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
      RETURNING *`,
      [
        sku.trim(), codigo_barras || null, nombre.trim(), descripcion || null,
        categoria_id || null, marca_id || null, unidad_medida_id || null,
        precio_costo || 0, precio_venta, precio_mayorista || null,
        moneda || 'UYU', stock_minimo || 0, stock_maximo || null,
        ubicacion_deposito || null, tiene_variantes || false,
        pais_origen || null, unidad_compra || 1, dias_entrega_prov || null,
        req.usuario.id,
      ]
    );
    res.status(201).json({ producto: rows[0] });
  } catch (err) { next(err); }
};

// PUT /api/productos/:id
const actualizar = async (req, res, next) => {
  try {
    const campos = [
      'nombre', 'descripcion', 'codigo_barras', 'categoria_id', 'marca_id',
      'precio_costo', 'precio_venta', 'precio_mayorista', 'stock_minimo',
      'stock_maximo', 'ubicacion_deposito', 'activo'
    ];
    const sets = [];
    const params = [];
    let i = 1;

    for (const campo of campos) {
      if (req.body[campo] !== undefined) {
        sets.push(`${campo} = $${i++}`);
        params.push(req.body[campo]);
      }
    }
    if (!sets.length) return res.status(400).json({ error: 'No hay campos para actualizar.' });

    params.push(req.params.id);
    const { rows } = await query(
      `UPDATE productos SET ${sets.join(', ')} WHERE id = $${i} RETURNING *`,
      params
    );
    if (!rows.length) return res.status(404).json({ error: 'Producto no encontrado.' });
    res.json({ producto: rows[0] });
  } catch (err) { next(err); }
};

// GET /api/productos/categorias
const listarCategorias = async (req, res, next) => {
  try {
    const { rows } = await query(
      'SELECT * FROM categorias WHERE activa = TRUE ORDER BY nombre'
    );
    res.json({ categorias: rows });
  } catch (err) { next(err); }
};

module.exports = { listar, obtener, crear, actualizar, listarCategorias };
