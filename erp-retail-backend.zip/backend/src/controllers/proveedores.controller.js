const { query } = require('../config/db');

const listar = async (req, res, next) => {
  try {
    const { estado, buscar } = req.query;
    let conditions = [];
    let params = [];
    let i = 1;
    if (estado) { conditions.push(`p.estado = $${i++}`); params.push(estado); }
    if (buscar) {
      conditions.push(`(p.razon_social ILIKE $${i} OR p.nombre_fantasia ILIKE $${i} OR p.rut ILIKE $${i})`);
      params.push(`%${buscar}%`); i++;
    }
    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const { rows } = await query(
      `SELECT p.id, p.razon_social, p.nombre_fantasia, p.rut, p.email, p.telefono,
              p.contacto_nombre, p.dias_pago, p.calificacion, p.estado,
              COUNT(DISTINCT oc.id) FILTER (WHERE oc.estado NOT IN ('cancelada','recibida')) AS oc_abiertas
       FROM proveedores p
       LEFT JOIN ordenes_compra oc ON oc.proveedor_id = p.id
       ${where}
       GROUP BY p.id
       ORDER BY p.razon_social`,
      params
    );
    res.json({ proveedores: rows });
  } catch (err) { next(err); }
};

const obtener = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM proveedores WHERE id = $1', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Proveedor no encontrado.' });

    const { rows: productos } = await query(
      `SELECT pp.*, p.nombre AS producto, p.sku
       FROM proveedor_productos pp
       JOIN productos p ON p.id = pp.producto_id
       WHERE pp.proveedor_id = $1 AND pp.activo = TRUE`,
      [req.params.id]
    );
    res.json({ proveedor: rows[0], productos });
  } catch (err) { next(err); }
};

const crear = async (req, res, next) => {
  try {
    const { razon_social, nombre_fantasia, rut, email, telefono, direccion, ciudad,
            pais, contacto_nombre, contacto_email, contacto_tel, dias_pago, descuento_pct, moneda } = req.body;
    if (!razon_social) return res.status(400).json({ error: 'Razón social requerida.' });

    const { rows } = await query(
      `INSERT INTO proveedores (razon_social, nombre_fantasia, rut, email, telefono,
        direccion, ciudad, pais, contacto_nombre, contacto_email, contacto_tel,
        dias_pago, descuento_pct, moneda, creado_por)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,
      [razon_social, nombre_fantasia||null, rut||null, email||null, telefono||null,
       direccion||null, ciudad||null, pais||'Uruguay', contacto_nombre||null,
       contacto_email||null, contacto_tel||null, dias_pago||30, descuento_pct||0,
       moneda||'UYU', req.usuario.id]
    );
    res.status(201).json({ proveedor: rows[0] });
  } catch (err) { next(err); }
};

const actualizar = async (req, res, next) => {
  try {
    const campos = ['razon_social','nombre_fantasia','email','telefono','direccion',
                    'ciudad','contacto_nombre','contacto_email','dias_pago','calificacion','estado','notas'];
    const sets = [];
    const params = [];
    let i = 1;
    for (const c of campos) {
      if (req.body[c] !== undefined) { sets.push(`${c} = $${i++}`); params.push(req.body[c]); }
    }
    if (!sets.length) return res.status(400).json({ error: 'Sin campos para actualizar.' });
    params.push(req.params.id);
    const { rows } = await query(
      `UPDATE proveedores SET ${sets.join(', ')} WHERE id = $${i} RETURNING *`, params
    );
    if (!rows.length) return res.status(404).json({ error: 'Proveedor no encontrado.' });
    res.json({ proveedor: rows[0] });
  } catch (err) { next(err); }
};

module.exports = { listar, obtener, crear, actualizar };
