require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const rateLimit = require('express-rate-limit');

const authRoutes        = require('./routes/auth.routes');
const usuariosRoutes    = require('./routes/usuarios.routes');
const productosRoutes   = require('./routes/productos.routes');
const lotesRoutes       = require('./routes/lotes.routes');
const proveedoresRoutes = require('./routes/proveedores.routes');
const comprasRoutes     = require('./routes/compras.routes');
const ventasRoutes      = require('./routes/ventas.routes');
const alertasRoutes     = require('./routes/alertas.routes');
const { errorHandler } = require('./middlewares/error.middleware');

const app = express();

// ── Middlewares globales ────────────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting general
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Demasiadas solicitudes, intente más tarde.' },
}));

// Rate limiting estricto para auth
app.use('/api/auth', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Demasiados intentos de acceso.' },
}));

// ── Health check ───────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── Rutas ──────────────────────────────────────────────────
app.use('/api/auth',        authRoutes);
app.use('/api/usuarios',    usuariosRoutes);
app.use('/api/productos',   productosRoutes);
app.use('/api/lotes',       lotesRoutes);
app.use('/api/proveedores', proveedoresRoutes);
app.use('/api/compras',     comprasRoutes);
app.use('/api/ventas',      ventasRoutes);
app.use('/api/alertas',     alertasRoutes);

// ── Manejo de errores ─────────────────────────────────────
app.use(errorHandler);

// ── Inicio ─────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✓ ERP API corriendo en puerto ${PORT} [${process.env.NODE_ENV}]`);
});

module.exports = app;
