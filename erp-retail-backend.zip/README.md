# ERP Retail

Sistema ERP para comercio retail con módulos de Ventas, Inventario, Compras y Proveedores.

---

## Stack

| Capa       | Tecnología                    |
|------------|-------------------------------|
| Frontend   | React + Vite + TailwindCSS    |
| Backend    | Node.js + Express             |
| Base datos | PostgreSQL                    |
| Deploy     | Railway (backend + BD) + Vercel (frontend) |

---

## Estructura del proyecto

```
erp-retail/
├── backend/
│   ├── migrations/
│   │   └── 001_schema.sql       ← Ejecutar primero en PostgreSQL
│   ├── src/
│   │   ├── config/db.js
│   │   ├── controllers/
│   │   ├── middlewares/
│   │   └── routes/
│   ├── .env.example
│   ├── package.json
│   └── railway.toml
└── frontend/                    ← Próximo paso
```

---

## Setup local

### 1. Base de datos

```bash
# Crear base de datos
createdb erp_retail

# Ejecutar migración
psql erp_retail < backend/migrations/001_schema.sql
```

### 2. Backend

```bash
cd backend
npm install

# Copiar y configurar variables de entorno
cp .env.example .env
# Editar .env con tu DATABASE_URL y JWT_SECRET

npm run dev
# API disponible en http://localhost:3000
```

### 3. Verificar

```bash
curl http://localhost:3000/api/health
# { "status": "ok", ... }

curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@erp.local","password":"TU_PASSWORD"}'
```

> Nota: el usuario admin se crea con el schema. Antes de usarlo, actualizá el password_hash
> con bcrypt real o ejecutá: `UPDATE usuarios SET password_hash = '$2b$12$...' WHERE email = 'admin@erp.local';`

---

## Deploy en Railway (testing en la nube)

### Pasos rápidos

1. Crear cuenta en [railway.app](https://railway.app) (gratis con GitHub)
2. **New Project → Deploy from GitHub repo**
3. Seleccionar tu repositorio
4. Railway detecta automáticamente Node.js
5. Agregar servicio **PostgreSQL** desde el dashboard
6. En variables de entorno del backend, agregar:
   ```
   DATABASE_URL=${{Postgres.DATABASE_URL}}
   JWT_SECRET=tu_secreto_seguro_aqui
   NODE_ENV=production
   ```
7. Ejecutar la migración: en Railway → PostgreSQL → Data → Query
   (pegar el contenido de `001_schema.sql`)
8. ¡Listo! Railway te da una URL pública automáticamente.

### Frontend en Vercel

1. Crear cuenta en [vercel.com](https://vercel.com)
2. **New Project → Import** desde GitHub (carpeta `frontend/`)
3. Variable de entorno: `VITE_API_URL=https://tu-backend.railway.app`
4. Deploy automático con cada push.

---

## Roles y permisos

| Rol       | Ventas | Inventario | Compras | Proveedores | Usuarios |
|-----------|--------|------------|---------|-------------|----------|
| admin     | ✓      | ✓          | ✓       | ✓           | ✓        |
| vendedor  | ✓      | ver        | —       | —           | —        |
| deposito  | —      | ✓          | ver     | —           | —        |
| compras   | —      | ver        | ✓       | ✓           | —        |

---

## Endpoints principales

### Auth
```
POST   /api/auth/login
GET    /api/auth/me
POST   /api/auth/cambiar-password
```

### Usuarios (solo admin)
```
GET    /api/usuarios
POST   /api/usuarios
PUT    /api/usuarios/:id
POST   /api/usuarios/:id/reset-password
GET    /api/usuarios/:id/auditoria
```

### Productos
```
GET    /api/productos
GET    /api/productos/:id
POST   /api/productos
PUT    /api/productos/:id
GET    /api/productos/categorias
```

### Lotes / Inventario
```
GET    /api/lotes?producto_id=...&proximos_vencer=true&dias=30
POST   /api/lotes
POST   /api/lotes/ajuste
```

### Ventas
```
GET    /api/ventas
GET    /api/ventas/:id
POST   /api/ventas          ← descuenta stock FIFO automáticamente
PATCH  /api/ventas/:id/estado
```

### Compras
```
GET    /api/compras
GET    /api/compras/:id
POST   /api/compras
PATCH  /api/compras/:id/estado
```

### Proveedores
```
GET    /api/proveedores
GET    /api/proveedores/:id
POST   /api/proveedores
PUT    /api/proveedores/:id
```

### Alertas
```
GET    /api/alertas
PATCH  /api/alertas/:id/resolver
```
